# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "Debug")
  file(REMOVE_RECURSE
  "Ai_Compiler_autogen"
  "CMakeFiles\\Ai_Compiler_autogen.dir\\AutogenUsed.txt"
  "CMakeFiles\\Ai_Compiler_autogen.dir\\ParseCache.txt"
  )
endif()
