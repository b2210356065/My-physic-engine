set(__QT_DEPLOY_TARGET_Ai_Compiler_FILE C:/Users/Lenovo/Desktop/Ai_Compieler/cmake-build-debug/Ai_Compiler.exe)
set(__QT_DEPLOY_TARGET_Ai_Compiler_TYPE EXECUTABLE)
set(__QT_DEPLOY_TARGET_Ai_Compiler_RUNTIME_DLLS C:/Qt/6.7.2/mingw_64/bin/Qt6Widgets.dll;C:/Qt/6.7.2/mingw_64/bin/Qt6Gui.dll;C:/Qt/6.7.2/mingw_64/bin/Qt6Core.dll)
